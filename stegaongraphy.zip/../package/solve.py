import pandas as pd
import warnings

warnings.simplefilter('ignore')

def pretty():
    print("="*53)

def main():
    # Read data from logfile
    data = pd.read_csv('02_Logfile.txt', sep=" - ", header=None)
    data.columns = ["Datetime", "User", "Ip", "Action"]
    data["Datetime"] = pd.to_datetime(data["Datetime"], format="mixed")

    # Find users with username 'unknown' and Action 'LOGIN'
    pretty()
    print("List of Logins by User 'unknown'")
    print(data[data['User'] == 'unknown'][data['Action'] == 'LOGIN'].sort_values(by="Datetime"))
    pretty()



    # Find suspicious late-night activity
    pretty()
    print("Users working between 10:00pm and 6:00am")
    times = data.set_index("Datetime")
    print(times.between_time('22:00', '6:00'))
    pretty()



    # Users who have not logged out after logging in
    sorted = data.sort_values(by="Datetime")
    # Get last logout time and check if there is a login at a later time
    logged_out = sorted[sorted['Action'] == "LOGOUT"][['User', 'Datetime']].groupby('User').max()
    still_logged_in = [user for (user, log_out_time) in logged_out.itertuples() if (any(log_in_time > log_out_time for log_in_time in sorted[sorted['Action'] == 'LOGIN'][sorted['User']==user]['Datetime']))]
    pretty()
    print("Useres that are still logged in:")
    print(still_logged_in)
    pretty()
        


    # Users who logged in from multiple IP addresses
    grouped = data[data['Action'] == 'LOGIN'].groupby('User').nunique()
    grouped = grouped[grouped['Ip'] > 1]
    pretty()
    print("Users with Logins from more than one IP address\n")
    print(grouped['Ip'])
    pretty()


    # IP addresses used for login
    ips = data[data['Action'] == 'LOGIN'].groupby('Ip').nunique()
    pretty()
    print("IPs with more than one login")
    print(ips[ips['User']>1]['User'])
    pretty()

    # special logins from non 192.168.*.* subnets
    logins = data[data['Action'] == 'LOGIN'][(data['Ip'] == '203.0.113.10') | (data['Ip'] == 'pretty()')].sort_values(by="Datetime")
    pretty()
    print("Logins by non local IPs")
    print(logins)
    pretty()

    # Login and Logout counts
    logins = data[data['Action'] == 'LOGIN'][['Datetime', 'User']].groupby('User').nunique()
    pretty()
    print("Number of Logins")
    print(logins)
    pretty()

    pretty()
    print("Number of Logouts")
    logouts = data[data['Action'] == 'LOGOUT'][['Datetime', 'User']].groupby('User').nunique()
    print(logouts)
    pretty()




if __name__ == "__main__":
    main()

