from dateutil import parser
import datetime

def main():
    logs = [];
    for l in open('02_Logfile.txt','r').readlines():
        parts = l.strip().split(' - ')
        logs.append({"timestamp": parser.parse(parts[0]), "user": parts[1], "ip": parts[2], "action": parts[3]})
    logs = list(sorted(logs, key=lambda log: log["timestamp"]))
    unauth = []
    late_night = []
    users = {}
    ips = {}
    for log in logs:
        if log["user"] == "unknown":
            unauth.append(log)
        if not (log["timestamp"].hour in range(6,22)):
            late_night.append(log)
        if not log["user"] in users.keys():
            users[log["user"]] = {"LOGIN": 0, "LOGOUT": 0, "LOGINSTATE": False}
        if log["action"] in ["LOGIN", "LOGOUT"]:    
            users[log["user"]][log["action"]] += 1
        if (not log["user"] in ips.keys()):
            ips[log["user"]] = []
        if (log["ip"] not in ips[log["user"]]) and log["action"] == "LOGIN":
            ips[log["user"]].append(log["ip"])
        if log["action"] in ["LOGIN", "LOGOUT"]:
            users[log["user"]]["LOGINSTATE"] = True if log["action"] == "LOGIN" else False
    unauth = map(lambda line: {"timestamp": line["timestamp"].isoformat(), "user": line["user"], "ip": line["ip"], "action": line["action"]},unauth)
    print("Unauthorized Access:")
    print('\n'.join('{}: {}'.format(*k) for k in enumerate(unauth)))
    print("Late night Access:")
    print('\n'.join('{}: {}'.format(*k) for k in enumerate(late_night)))
    loggedIn = []
    for key,val in users.items():
        if val["LOGINSTATE"] == True:
            loggedIn.append(key)
    print("Not logged out after logging in:")
    print('\n'.join('{}: {}'.format(*k) for k in enumerate(loggedIn)))
    multiIps = []
    for key,val in ips.items():
        if len(val) > 1:
            multiIps.append(key)
    print("Users with different IPs:")
    print('\n'.join('{}: {}'.format(*k) for k in enumerate(multiIps)))
if __name__ == '__main__':
    main()
