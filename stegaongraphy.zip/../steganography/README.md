# Steganography Yay
In the Steganography-Tools folder you will find a setup script that you can run and also a main.py that you can invoke afterwards with 
```
./script.sh
./main.py
```
(Crazy, right? But please run it in the Steganography-Tools directory, or else the paths are completely f...ed)

Please note that for the most part the code comes from an *interesting* Github repo we found and was cleaned up using chatgpt.
There is a lot that can be done to improve the experience, for example create a somewhat usable GUI.
Also note that the output image should end in "*.png" or else decoding will probably fail.
Also note that the resulting text might or might not show up as normal text depending on the editor. Notepad works, as 
well as simply printing out the text with cat. 




There is also the possibility to run a server for a website, which might be a bit more user friendly, but only supports image steganography
Easiest way is probably going into the server directory and just running

```
python3 -m http.server 5000
```

or something like that.